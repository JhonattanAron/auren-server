#version 120

// Fragment shader simple para bloques dañados

uniform sampler2D texture;
varying vec2 texcoord;

void main() {
    vec4 color = texture2D(texture, texcoord);
    gl_FragData[0] = color;
}
