#version 120

#include "/lib/config.glsl"



uniform sampler2D gaux3;


varying vec2 texcoord;
varying float exposure;



void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    texcoord = gl_MultiTexCoord0.xy;

    exposure = texture2D(gaux3, vec2(0.5)).r;
}
