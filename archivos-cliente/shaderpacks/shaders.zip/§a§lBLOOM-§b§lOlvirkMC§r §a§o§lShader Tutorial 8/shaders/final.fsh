#version 120

#include "/lib/config.glsl"


/*
const int gaux3Format = R16F;
*/


const bool colortex0Clear = false;
const bool colortex1Clear = false;
const bool colortex2Clear = false;
const bool colortex3Clear = false;
const bool gaux1Clear = false;
const bool gaux2Clear = false;
const bool gaux3Clear = false;
const bool gaux4Clear = false;


uniform sampler2D colortex1;


varying vec2 texcoord;
varying float exposure;

void main() {
    vec2 pixelUV = texcoord;
    vec3 block_color = texture2DLod(colortex1, pixelUV, 0.0).rgb;
    gl_FragData[0] = vec4(block_color, 1.0); // Fuerza alpha a 1.0 para evitar desaparición de objetos translúcidos
}