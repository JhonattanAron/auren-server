#version 120

#include "lib/config.glsl"


uniform ivec2 eyeBrightnessSmooth;

uniform sampler2D colortex1;
uniform sampler2D gaux3;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTime;


varying vec2 texcoord;
varying float exposure;



#include "lib/luma.glsl"


void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    texcoord = gl_MultiTexCoord0.xy;

    vec2 eye_bright_smooth = vec2(eyeBrightnessSmooth);

    // Exposure
    #if !defined SIMPLE_AUTOEXP
        float mipmap_level = log2(min(viewWidth, viewHeight)) - 1.0;

        vec3 exposure_col = texture2DLod(colortex1, vec2(0.5), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.25), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.75), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.25, 0.75), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.75, 0.25), mipmap_level).rgb;
        
        exposure = clamp(luma(exposure_col), 0.0005, 100.0);

        float prev_exposure = texture2D(gaux3, vec2(0.5)).r;

        exposure = (exp(-exposure) * 3.25) + 0.6;
        exposure = mix(exposure, prev_exposure, exp(-frameTime * 1.5));
    #else
        exposure = 1.0;
    #endif


}
