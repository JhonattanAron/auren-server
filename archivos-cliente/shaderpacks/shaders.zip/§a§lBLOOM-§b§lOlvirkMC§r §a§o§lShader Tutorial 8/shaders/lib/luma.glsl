// Calcula la luminancia (brillo percibido) de un color RGB
float luma(vec3 color) {
    // Usa coeficientes estándar para la percepción humana
    return dot(color, vec3(0.2126, 0.7152, 0.0722));
}


