// Calcula un efecto de desenfoque (bloom) usando muestreo múltiple y mipmaps
vec3 mipmap_bloom(sampler2D image, vec2 coords, float dither) {
    // Acumula el color desenfocado
    vec3 blur_sample = vec3(0.0);
    // Define el radio de desenfoque, ajustado por la relación de aspecto
    vec2 blur_radius_vec = vec2(0.1 * inv_aspect_ratio, 0.1);

    // Número de muestras para el desenfoque (definido por macro)
    int sample_c = int(BLOOM_SAMPLES);

    // Factor para espaciar las muestras de desenfoque
    vec2 blur_radios_factor = blur_radius_vec * (1.0 / BLOOM_SAMPLES);
    float n;
    vec2 offset;
    float dither_x;

    // Bucle para tomar muestras alrededor del píxel actual
    for(int i = 0; i < sample_c; i++) {
        // Añade dithering para evitar patrones repetitivos
        dither_x = i + dither;
        // Calcula un ángulo pseudoaleatorio para la muestra
        n = fract(dither_x * 1.6180339887) * 3.141592653589793;
        // Calcula el desplazamiento de la muestra usando el ángulo y el radio
        offset = vec2(cos(n), sin(n)) * dither_x * blur_radios_factor;

        // Suma la muestra desplazada positiva
        blur_sample += texture2D(image, coords + offset, -1.0).rgb;
        // Suma la muestra desplazada negativa
        blur_sample += texture2D(image, coords - offset, -1.0).rgb;
    }

    // Normaliza el resultado según la cantidad de muestras y la fuerza del bloom
    blur_sample /= (BLOOM_SAMPLES * 3.0) / BLOOM_STRENGTH;

    // Devuelve el color desenfocado (bloom)
    return blur_sample;
}
