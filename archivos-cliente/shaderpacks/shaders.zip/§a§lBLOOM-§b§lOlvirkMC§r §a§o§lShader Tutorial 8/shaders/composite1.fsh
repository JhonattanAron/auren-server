#version 120

#include "/lib/config.glsl"


const bool gaux1MipmapEnabled = true;


uniform sampler2D colortex1;
uniform sampler2D gaux1;
uniform float inv_aspect_ratio;





varying vec2 texcoord;

#include "/lib/bloom.glsl"
#include "/lib/dither.glsl"


void main() {
    vec4 block_color = texture2DLod(colortex1, texcoord, 0);

    float dither = semiblue(gl_FragCoord.xy);

    #ifdef BLOOM
        vec3 bloom = mipmap_bloom(gaux1, texcoord, dither);
        block_color.rgb += bloom;
    #endif

    block_color = clamp(block_color, vec4(0.0), vec4(vec3(50.0), 1.0));
    /* DRAWBUFFERS:1 */
    gl_FragData[0] = block_color;
}
